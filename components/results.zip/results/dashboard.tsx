"use client";

import React, { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import dynamic from "next/dynamic";
import { cn } from "@/lib/utils";
import { Activity, AlertTriangle, Anchor, ChevronRight, Crosshair, Filter, ShieldAlert, Ship, Signal, Users } from "lucide-react";

// Dynamic import MapView
const MapView = dynamic(() => import("./results-map"), {
    ssr: false,
    loading: () => <div className="w-full h-full bg-[#050505] animate-pulse" />
});

interface VesselData {
    id: string;
    name: string;
    risk: number;
    status: string;
    lat: number;
    lng: number;
    lastSeen: string;
    type: string;
    flag: string;
    ais_status: string;
    cnn_confidence: number;
    detection_confidence: number;
    behavior_analysis: any;
    coordinates: string;
}

interface AnalysisResults {
    detection_summary: {
        total_detections: number;
        dark_vessels: number;
        high_risk_vessels: number;
    };
    intelligence_analysis: any; // Simplified for now
}

export function Dashboard() {
    const params = useParams();
    const [vessels, setVessels] = useState<VesselData[]>([]);
    const [selectedVesselId, setSelectedVesselId] = useState<string | null>(null);
    // Fixed View Mode
    const [analysisResults, setAnalysisResults] = useState<AnalysisResults | null>(null);
    const [loading, setLoading] = useState(true);
    const [mapCenter, setMapCenter] = useState<[number, number]>([20, -160]);

    useEffect(() => {
        if (!params.id) return;

        const fetchResults = async () => {
            try {
                let url = `http://127.0.0.1:5001/api/analysis/${params.id}/results`;

                // Frontend-Only Mode: Check for static scenarios
                const STATIC_SCENARIOS = ["simulated_traffic", "papahanaumokuakea"];
                if (STATIC_SCENARIOS.includes(params.id as string)) {
                    url = `/data/scenarios/${params.id}.json`;
                }

                const res = await fetch(url);
                if (!res.ok) throw new Error("Failed to load results");

                const data = await res.json();

                const rawVessels = data.vessels || [];
                const formattedVessels: VesselData[] = rawVessels.map((v: any, index: number) => {
                    // RESOLVE ANALYSIS TEXT
                    // 1. Try direct string on vessel object (Papahanaumokuakea)
                    let reasoning = (typeof v.analysis === 'string') ? v.analysis : "";

                    // 2. Try nested behavior_analysis object
                    if (!reasoning && v.behavior_analysis?.reasoning) {
                        reasoning = v.behavior_analysis.reasoning;
                    }

                    // 3. Try lookup in detailed_vessel_analyses (Simulated Traffic)
                    if (!reasoning) {
                        const intellect = data.intelligence_analysis || data.intelligence_summary;
                        if (intellect?.detailed_vessel_analyses) {
                            const match = intellect.detailed_vessel_analyses.find((d: any) =>
                                d.vessel_id === v.vessel_id || d.vessel_id === v.id
                            );
                            if (match?.analysis) {
                                reasoning = match.analysis;
                            }
                        }
                    }

                    // Constuct final behavior analysis object
                    const finalBehavior = v.behavior_analysis || {};
                    if (reasoning) {
                        finalBehavior.reasoning = reasoning;
                    }

                    return {
                        id: v.id || v.vessel_id || `Unknown-${index}`,
                        name: v.name || v.vessel_id || `Vessel ${index + 1}`,
                        risk: v.risk || v.risk_score || 0,
                        status: v.status || (v.risk_score > 50 ? "SUSPICIOUS" : "CLEAR"),
                        lat: (typeof v.lat === 'number') ? v.lat : (typeof v.latitude === 'number' ? v.latitude : 0),
                        lng: (typeof v.lng === 'number') ? v.lng : (typeof v.longitude === 'number' ? v.longitude : 0),
                        lastSeen: v.lastSeen || "Just now",
                        type: v.type || "Unknown",
                        flag: v.flag || "Unknown",
                        ais_status: v.ais_status || "UNKNOWN",
                        cnn_confidence: v.cnn_confidence || 0,
                        detection_confidence: v.detection_confidence || 0,
                        behavior_analysis: finalBehavior,
                        coordinates: v.coordinates || `${(v.latitude || 0).toFixed(4)}°N, ${(v.longitude || 0).toFixed(4)}°E`
                    };
                });

                setVessels(formattedVessels);
                // Handle different key names in static vs dynamic
                setAnalysisResults({
                    detection_summary: data.detection_summary,
                    intelligence_analysis: data.intelligence_analysis || data.intelligence_summary
                });

                // Auto-select first critical or high risk vessel
                const priorityVessel = formattedVessels.find(v => (v.risk > 80)) || formattedVessels[0];
                if (priorityVessel) {
                    setSelectedVesselId(priorityVessel.id.toString()); // Ensure string ID
                    if (priorityVessel.lat && priorityVessel.lng) {
                        setMapCenter([priorityVessel.lat, priorityVessel.lng]);
                    }
                }

            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchResults();
    }, [params.id]);

    const selectedVessel = vessels.find(v => v.id === selectedVesselId);

    // Calculate Map Markers
    const mapMarkers = vessels.map(v => ({
        id: v.id,
        lat: v.lat,
        lng: v.lng,
        risk: v.risk,
        name: v.name,
        status: v.status
    }));

    if (loading) {
        return (
            <div className="h-screen w-full bg-black flex items-center justify-center text-cyan-500">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
                    <span className="font-mono animate-pulse">RETRIEVING INTELLIGENCE...</span>
                </div>
            </div>
        );
    }

    return (
        <div className="flex h-screen w-full bg-[#050505] text-white overflow-hidden font-sans">

            {/* LEFT PANEL: VESSEL LIST */}
            <aside className="w-80 flex flex-col border-r border-white/10 bg-black/80 backdrop-blur z-20 shrink-0">
                <div className="h-16 flex items-center px-6 border-b border-white/10 shrink-0">
                    <div className="flex items-center gap-2 text-cyan-400">
                        <ShieldAlert className="w-5 h-5" />
                        <span className="font-bold tracking-wider">DETECTED VESSELS</span>
                    </div>
                    <div className="ml-auto bg-cyan-900/40 text-cyan-400 px-2 py-0.5 rounded text-xs font-mono border border-cyan-500/30">
                        {vessels.length} SIGNALS
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                    {vessels.map(vessel => (
                        <div
                            key={vessel.id}
                            onClick={() => {
                                setSelectedVesselId(vessel.id);
                                setMapCenter([vessel.lat, vessel.lng]);
                            }}
                            className={cn(
                                "p-3 rounded-lg border cursor-pointer transition-all hover:bg-white/5",
                                selectedVesselId === vessel.id
                                    ? "bg-white/10 border-cyan-500/50 shadow-[inset_0_0_10px_rgba(6,182,212,0.1)]"
                                    : "border-transparent hover:border-white/10"
                            )}
                        >
                            <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center gap-2">
                                    <Ship className={cn("w-4 h-4", vessel.risk > 80 ? "text-red-500" : vessel.risk > 40 ? "text-yellow-500" : "text-green-500")} />
                                    <span className="font-bold text-sm tracking-wide">ID: {vessel.id}</span>
                                </div>
                                <span className={cn(
                                    "text-xs font-bold",
                                    vessel.risk > 80 ? "text-red-500" : vessel.risk > 40 ? "text-yellow-500" : "text-green-500"
                                )}>
                                    {vessel.risk}%
                                </span>
                            </div>
                            <div className="flex justify-between items-end">
                                <span className="text-[10px] text-gray-500 uppercase">{vessel.status} • {vessel.lastSeen}</span>
                            </div>
                        </div>
                    ))}
                </div>
            </aside>

            {/* CENTER: MAP */}
            <main className="flex-1 relative bg-black min-w-0">
                <div className="absolute top-4 left-4 z-[400] bg-black/80 backdrop-blur border border-white/10 rounded-full px-4 py-2 flex items-center gap-3 shadow-xl">
                    <Crosshair className="w-4 h-4 text-cyan-400" />
                    <input
                        type="text"
                        placeholder="SEARCH COORDS // ID"
                        className="bg-transparent border-none outline-none text-xs w-48 text-white placeholder:text-gray-600 font-mono"
                    />
                </div>

                <div className="absolute inset-0 z-0">
                    <MapView
                        readOnly={true}
                        vessels={vessels}
                        selectedVesselId={selectedVesselId}
                        onVesselSelect={(id: string | null) => {
                            setSelectedVesselId(id);
                            if (id) {
                                const v = vessels.find(v => v.id === id);
                                if (v) setMapCenter([v.lat, v.lng]);
                            }
                        }}
                        center={mapCenter}
                        zoom={9}
                    />
                </div>
            </main>

            {/* RIGHT PANEL: DETAILS */}
            <aside className="w-96 flex flex-col border-l border-white/10 bg-black/90 backdrop-blur z-20 shrink-0">
                {/* Header */}
                <div className="h-16 flex items-center px-6 border-b border-white/10 shrink-0 gap-3 text-cyan-400">
                    <Activity className="w-5 h-5" />
                    <h2 className="font-bold tracking-wider uppercase text-sm">Mission Intelligence</h2>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                    {/* 1. SCENARIO REPORT (Always Visible) */}
                    {analysisResults?.intelligence_analysis ? (
                        <div className="space-y-6 pb-6 border-b border-white/10">
                            {/* Exec Summary */}
                            <div className="space-y-3">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                    <Signal className="w-3 h-3" /> Global Situation
                                </h3>
                                <p className="text-sm text-gray-300 leading-relaxed border-l-2 border-cyan-500 pl-4">
                                    {analysisResults.intelligence_analysis.executive_summary}
                                </p>
                            </div>
                            {/* Threat Assessment */}
                            <div className="p-3 bg-red-950/20 border border-red-900/30 rounded">
                                <h4 className="text-xs font-bold text-red-400 uppercase mb-1">Threat Level</h4>
                                <p className="text-sm text-red-200">
                                    {analysisResults.intelligence_analysis.threat_assessment}
                                </p>
                            </div>
                        </div>
                    ) : (
                        <div className="p-4 bg-white/5 rounded text-xs text-gray-500 text-center uppercase tracking-widest">
                            Loading Intelligence...
                        </div>
                    )}

                    {/* 2. SELECTED TARGET (If any) */}
                    <div>
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Crosshair className="w-3 h-3" />
                            {selectedVessel ? `Target Analysis: ${selectedVessel.id}` : "Select Target"}
                        </h3>

                        {selectedVessel ? (
                            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
                                {/* Risk Score */}
                                <div className="flex bg-white/5 rounded p-3 items-center justify-between border border-white/5">
                                    <span className="text-sm font-bold text-gray-400">Risk Score</span>
                                    <span className={cn("text-xl font-bold", selectedVessel.risk > 80 ? "text-red-500" : selectedVessel.risk > 40 ? "text-yellow-500" : "text-green-500")}>
                                        {selectedVessel.risk}/100
                                    </span>
                                </div>

                                {/* AI Reasoning */}
                                <div className="p-4 border border-cyan-500/20 bg-cyan-500/5 rounded relative">
                                    <p className="text-xs leading-relaxed text-gray-300">
                                        <span className="text-white font-bold block mb-2">NEURAL ASSESSMENT:</span>
                                        {selectedVessel.behavior_analysis?.reasoning || "Analyzing signatures..."}
                                    </p>
                                </div>

                                {/* Details Grid */}
                                <div className="grid grid-cols-2 gap-2 text-xs">
                                    <div className="bg-black/40 p-3 rounded border border-white/5">
                                        <div className="text-gray-500 mb-1 uppercase tracking-wider text-[10px]">Type</div>
                                        <div className="font-bold flex items-center gap-2">
                                            <Ship className="w-3 h-3 text-cyan-500" />
                                            {selectedVessel.type}
                                        </div>
                                    </div>
                                    <div className="bg-black/40 p-3 rounded border border-white/5">
                                        <div className="text-gray-500 mb-1 uppercase tracking-wider text-[10px]">Flag</div>
                                        <div className="font-bold flex items-center gap-2">
                                            <Users className="w-3 h-3 text-cyan-500" />
                                            {selectedVessel.flag}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="h-32 flex items-center justify-center border border-dashed border-white/10 rounded bg-white/5">
                                <div className="text-center">
                                    <Crosshair className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                                    <span className="text-[10px] text-gray-600 uppercase tracking-widest">No Signal Selected</span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </aside>

        </div>
    );
}
