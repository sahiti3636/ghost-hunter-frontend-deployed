"use client";

import React, { useEffect } from 'react';
import { MapContainer, ImageOverlay, CircleMarker, Popup, useMap, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Vessel } from '@/lib/api';

// Fix Leaflet marker icons
// delete (L.Icon.Default.prototype as any)._getIconUrl;
// L.Icon.Default.mergeOptions({
//     iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png').default.src,
//     iconUrl: require('leaflet/dist/images/marker-icon.png').default.src,
//     shadowUrl: require('leaflet/dist/images/marker-shadow.png').default.src,
// });

interface ResultsMapProps {
    imageUrl?: string;
    bounds?: [[number, number], [number, number]];
    vessels: Vessel[];
    selectedVesselId: string | null;
    onVesselSelect: (id: string) => void;
}

// Component to handle map view updates
function MapUpdater({ bounds, center, zoom }: { bounds?: [[number, number], [number, number]], center?: [number, number], zoom?: number }) {
    const map = useMap();

    useEffect(() => {
        if (bounds) {
            map.fitBounds(bounds);
        }
    }, [bounds, map]);

    useEffect(() => {
        if (center) {
            map.setView(center, zoom || map.getZoom());
        }
    }, [center, zoom, map]);

    return null;
}

export default function ResultsMap({ imageUrl, bounds, vessels, selectedVesselId, onVesselSelect, center, zoom, readOnly }: ResultsMapProps & { center?: [number, number], zoom?: number, readOnly?: boolean }) {

    // Default bounds (Global) if none provided
    const defaultBounds: [[number, number], [number, number]] = [[-60, -180], [80, 180]];
    const mapBounds = bounds || (!center ? defaultBounds : undefined);

    const getRiskColor = (risk: number) => {
        if (risk >= 90) return "#ef4444"; // red-500
        if (risk >= 50) return "#eab308"; // yellow-500
        return "#22c55e"; // green-500
    };

    return (
        <MapContainer
            bounds={mapBounds}
            center={center}
            zoom={zoom || 10}
            style={{ height: '100%', width: '100%', background: '#050505' }}
            scrollWheelZoom={true}
            attributionControl={false}
        >
            <MapUpdater bounds={mapBounds} center={center} zoom={zoom} />

            {/* Base Map (OpenStreetMap) */}
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />

            {/* Satellite Image Overlay - DISABLED PER USER REQUEST */}
            {/* {imageUrl && bounds && (
                <ImageOverlay
                    url={imageUrl}
                    bounds={bounds}
                    opacity={0.8}
                />
            )} */}

            {/* Vessel Markers */}
            {vessels.map((vessel) => {
                const isSelected = vessel.id === selectedVesselId;
                return (
                    <CircleMarker
                        key={vessel.id}
                        center={[vessel.lat, vessel.lng]}
                        radius={isSelected ? 8 : 5}
                        pathOptions={{
                            color: isSelected ? '#fff' : getRiskColor(vessel.risk),
                            fillColor: getRiskColor(vessel.risk),
                            fillOpacity: 0.8,
                            weight: isSelected ? 3 : 1
                        }}
                        eventHandlers={{
                            click: () => onVesselSelect(vessel.id)
                        }}
                    >
                        <Popup className="custom-popup">
                            <div className="text-black font-sans text-xs">
                                <strong>{vessel.name || vessel.id}</strong><br />
                                Risk: {vessel.risk}%<br />
                                Status: {vessel.status}
                            </div>
                        </Popup>
                    </CircleMarker>
                );
            })}
        </MapContainer>
    );
}